// Angular Rails Template
// source: lib/assets/bower_components/angular-social/src/views/buttons.html

angular.module("templates").run(["$templateCache", function($templateCache) {
  $templateCache.put("angular-social/src/views/buttons.html", '<div class="ng-social-container ng-cloak"><ul class="ng-social" ng-transclude></ul></div>')
}]);

