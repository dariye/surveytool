var app = angular.module('SSDemoApp', [
  'ngAnimate',
  'ngResource',
  'ngRoute',
  'ngSocial',
  'ui.router',
  'ngSocial',
  'duScroll',
  'templates'
]);
