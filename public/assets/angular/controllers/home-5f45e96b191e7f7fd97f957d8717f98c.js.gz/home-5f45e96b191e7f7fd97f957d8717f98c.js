'use strict';

app.controller('HomeCtrl', ['$scope', function ($scope) {
  console.log("Hello I'm in HOme");
}]);
