'use strict';

app.factory('Questions', [function () {

  var questionList =
  [
    "Do you want to learn how our platform can help your fundraising campaign?",
    "Lorem.Turpius.Praeterita. Turpius.Praeterita?",
    "Lorem.Turpius.Praeterita. Turpius.Praeterita Praeterita?"
  ];

  return questionList;
}]);
