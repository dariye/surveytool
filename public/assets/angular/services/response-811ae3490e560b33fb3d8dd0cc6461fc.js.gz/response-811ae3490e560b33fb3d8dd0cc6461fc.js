'use strict';

app.factory('responses', [function () {

  var r = {
    responses: []
  };


  return r;
}]);
